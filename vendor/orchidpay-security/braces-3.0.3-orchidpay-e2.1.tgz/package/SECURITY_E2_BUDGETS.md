# Private laboratory delta

Name/version unchanged: braces 3.0.3. No advisory waiver or upstream-release claim.
Hard ceilings: 4096 results per expansion and aggregate array API; 1048576 UTF-16 output code units; 20000 AST nodes; 262144 explicitly counted work units; 8388608 cumulatively generated UTF-16 code units. Array input total length 10000 code units. Values may be lowered, not raised.
These are project laboratory policy limits, not values mandated by the upstream advisory. Long legitimate inputs may now be rejected intentionally. Runtime CPU/time/memory confinement remains necessary. Executable getters, proxies and callbacks belong to trusted configuration, not untrusted data.
Parent R2 depth/cycle/canonical parse behavior preserved except NaN maxLength no longer bypasses the 10000 ceiling. Numeric non-safe-integer enumeration is rejected before fill-range.
